from django.urls import path
from . import views
from django.conf import settings
from django.contrib.staticfiles.urls import static, staticfiles_urlpatterns

urlpatterns = [
				path('', views.index, name='index'),
                path('login/', views.login, name='login'),
                path('register/', views.register, name='register'),
                path('logout/', views.logout, name='logout'),
                path('home/', views.home, name='home'),
                ########### CURRENT URLS ##########################
                path('sendmsg/', views.addmsg, name='sendmsg'),
                path('viewmsg/', views.viewmsg, name='viewmsg'),
                
]